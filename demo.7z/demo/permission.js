import router from './router'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from '@/utils/auth' // get token from cookie
import getPageTitle from '@/utils/get-page-title'
import CAS from '@/api/sso' // 对接单点登录

NProgress.configure({ showSpinner: false }) // NProgress配置

router.beforeEach((to, from, next) => {
  NProgress.start()
  CAS.enableCasAuth()
  // 设置页面标题
  document.title = getPageTitle(to.meta.title)

  // 确定用户是否已登录
  const hasToken = getToken()
  if (hasToken) {
    next()
    NProgress.done()
  } else {
    NProgress.done()
  }
})

router.afterEach(() => {
  // finish progress bar
  NProgress.done()
})
