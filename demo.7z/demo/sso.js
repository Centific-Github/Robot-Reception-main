import axios from 'axios'
import request from '@/utils/request'
import { getToken, setToken } from '@/utils/auth'

const casServerUrl = process.env.VUE_APP_CASSERVERURL;
const casLoginUrl = `${casServerUrl}/login`;
const sysDomain = process.env.VUE_APP_SYS_DOMAIN;
export default{
    
    enableCasAuth(){
        if(window.location.href.indexOf("isCasIframe=1") != -1) {
            return;
        }
        
        if (getToken()){
          return;
        }
        
        let url = window.location.href;
        console.log("url : " + url)

        if (!this.isCasCallback()){
            this.toAuth();
            return
        }

        let ticket = this.getTicket();
        if(ticket){
            this.login(ticket);
        }
    },
    login(ticket){
        
        let params = {
            "ticket":ticket,
            "service":sysDomain
        }
        
        this.getAccessToken(params).then(res => {
            console.log(res)
            if (res && !res.success && res.message){
                alert(res.message)
                return;
            }
            setToken(res.access_token);
            this.toIndex();
        }).catch(e => {
            console.log(e)
        });
    },
    toAuth(){
        location.href = `${casLoginUrl}?service=${sysDomain}`;
    },
    toIndex(){
        location.href = `${sysDomain}/#/dashboard`;
    },
    getTicket(){
        var reg = new RegExp("(^|&)ticket=([^&]*)(&|$)", "i"); 
        var r = window.location.search.substr(1).match(reg); 
        if (r != null) return unescape(r[2]); 
        return null; 
    },
    isCasCallback(){
        let url = window.location.href;
        return url.indexOf(sysDomain + "/?ticket=") != -1
    },
    getAccessToken(params){

        return request({
            url:`api-auth/oauth/cas/token`,
            method: 'post',
            params:params,
            headers:{
                'client_id': 'webApp',
                'client_secret': 'webApp'
            }
        });
    },
    logout(){
        location.href = `${casServerUrl}/logout?service=${sysDomain}`;
    }
}